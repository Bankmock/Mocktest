 
 function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
}
 
 
 
 function mockbuy2() {
    document.getElementById("id02").style.display="block";
  
} 

 function mockbuy3() {
    document.getElementById("id03").style.display="block";
  
} function mockbuy4() {
    document.getElementById("id04").style.display="block";
  
} function mockbuy5() {
    document.getElementById("id05").style.display="block";
  
}  




 

function Registration2() {
       var inpass = document.getElementById("inpass").value;
	           
	     if (inpass == 880105) {
			   window.location.href = "./mocktest/mock2/login.html";
                    } else {
            alert("your code in wrong");
                 }
            }
 function Registration3() {
       var inpass = document.getElementById("inpass").value;
	     if (inpass == 880105) {
			   window.location.href = "./mocktest/mock3/login.html";
                    } else {
            alert("your code in wrong");
                 }
            }
 function Registration4() {
       var inpass = document.getElementById("inpass").value;
	     if (inpass == 880105) {
			   window.location.href = "./mocktest/mock4/login.html";
                    } else {
            alert("your code in wrong");
                 }
            }
 function Registration5() {
       var inpass = document.getElementById("inpass").value;
	     if (inpass == 880105) {
			   window.location.href = "./mocktest/mock5/login.html";
                    } else {
            alert("your code in wrong");
                 }
            }
 
 


 






















 /* function subscription() {
       var inpass = document.getElementById("inpass").value;
	   var a = document.querySelectorAll("a");
          if (inpass == 050916) {
			  /* if (a.className == "sucode1") {
               alert("kuldip");
			  } */ /* if (a.class == "sucode2") {
               window.location.href = "../mocktest/mock3/login.html";
			  } */ /* else if (a.class == "sucode3") {
               window.location.href = "../mocktest/mock4/login.html";
			  } else if (a.class == "sucode4") {
               window.location.href = "../mocktest/mock5/login.html";
			  } else if (a.class == "sucode1") {
               window.location.href = "../mocktest/mock6/login.html";
			  } */
          /* } else {
            alert("your code in wrong");
                 }
				 
				 
            }
    */ 
			
 /* function subscrip tion6() {
       var inpass = document.getElementById("inpass").value;
	   var stag = document.querySelector(a.class);
	   switch(stag.class) {
	   case "sucode1":
          if (inpass == 050916) {
               window.location.href = "../mocktest/mock2/login.html";
          } else/*  {
            alert("your code in wrong");
                 } */
      /*  break;

case "sucode2":
          if (inpass == 050916) {
               window.location.href = "../mocktest/mock3/login.html";
          } else {
            alert("your code in wrong");
                 }
       break;
	   case "sucode3":
          if (inpass == 050916) {
               window.location.href = "../mocktest/mock4/login.html";
          } else {
            alert("your code in wrong");
                 }
       break;
case "sucode4":
          if (inpass == 050916) {
               window.location.href = "../mocktest/mock5/login.html";
          } else {
            alert("your code in wrong");
                 }
       break;

case "sucode5":
          if (inpass == 050916) {
               window.location.href = "../mocktest/mock6/login.html";
          } else {
            alert("your code in wrong");
                 }
       break;
case "sucode6":
          if (inpass == 050916) {
               window.location.href = "../mocktest/mock7/login.html";
          } else {
            alert("your code in wrong");
                 }
       break;
	   } */ 




  